function colorInit() {
	var h = window.innerHeight;
	var w = window.innerWidth;
	var color = "grey";
	var heightInit = h + "px";
	var widthInit = w + "px";
	document.getElementById("box").style.background = color;
	document.getElementById("box").style.height = heightInit;
	document.getElementById("box").style.width = widthInit;
}

function boxResize() {
	var h = window.innerHeight;
	var w = window.innerWidth;
	var newHeight = h + "px";
	var newWidth = w + "px";
	document.getElementById("box").style.height = newHeight;
	document.getElementById("box").style.width = newWidth;
}

function colorShift(e) {
	var mouseX = e.clientX;
	var mouseY = e.clientY;
	var windowWidth = window.innerWidth;
	var windowHeight = window.innerHeight;
	var coordX = convertToCenterOrigin(mouseX,windowWidth);
	var coordY = convertToCenterOrigin(mouseY,windowHeight);
	var radiusFromCenter = findRadFromCenter(coordX,coordY);
	var windowRadMax = findRadFromCenterMax(windowHeight,windowWidth);
	var radiusNormal = findRadFromCenterNormal(radiusFromCenter,windowRadMax);
	var color = findAngleFromCoord(coordX,coordY);
	var saturation = radiusNormal * 100;
	var luminance = 100 - (50 * radiusNormal);
	var colorUpdate = "hsl(" + color + "," + saturation + "%," + luminance + "%)";
	document.getElementById("box").style.background = colorUpdate;
}

function convertToCenterOrigin (x,maxX) {
	var coord = x - (maxX/2);
	return coord;
}

function findRadFromCenter(x,y) {
	var radFromCenter = Math.sqrt(x*x + y*y);
	return radFromCenter;
}

function findRadFromCenterMax (h,w){
	var radFromCenterMax;
	if (h<=w){
		radFromCenterMax = h / 2;
	} else {
		radFromCenterMax = w / 2;
	}
	return radFromCenterMax;
}

function findRadFromCenterNormal (r, m) {
	if (r <= m){
		radFromCenterNormal = r / m;
	} else {
		radFromCenterNormal = 1;
	} 
	return radFromCenterNormal;
}

function findAngleFromCoord(x,y){
	var theta = Math.atan(y/x);
	if (x <= 0 && y <=0) {
		var degrees = ((theta + Math.PI) / Math.PI) * 180;
	} else if (x <= 0 && y > 0) {
		var degrees = (theta / Math.PI) * 180 - 180;
	} else {
		var degrees = (theta / Math.PI) * 180 - 360;
	}
	return degrees;
}
